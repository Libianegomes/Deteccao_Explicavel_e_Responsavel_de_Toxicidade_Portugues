from pathlib import Path
import pandas as pd
import numpy as np


DATA_RAW = Path("data/raw")
DATA_PROCESSED = Path("data/processed")


def read_any_file(path: str | Path) -> pd.DataFrame:
    """
    Lê arquivos CSV, TSV, JSON, JSONL, XLSX ou Parquet.
    """
    path = Path(path)

    if not path.exists():
        raise FileNotFoundError(f"Arquivo não encontrado: {path}")

    suffix = path.suffix.lower()

    if suffix == ".csv":
        return pd.read_csv(path)

    if suffix == ".tsv":
        return pd.read_csv(path, sep="\t")

    if suffix in [".xlsx", ".xls"]:
        return pd.read_excel(path)

    if suffix == ".json":
        return pd.read_json(path)

    if suffix == ".jsonl":
        return pd.read_json(path, lines=True)

    if suffix == ".parquet":
        return pd.read_parquet(path)

    raise ValueError(f"Formato não suportado: {suffix}")


def normalize_text(text: str) -> str:
    """
    Normalização mínima. Não remova pontuação agressivamente agora,
    porque pontuação, caixa alta e palavrões podem ser sinais úteis.
    """
    if pd.isna(text):
        return ""

    text = str(text)
    text = text.replace("\n", " ").replace("\r", " ")
    text = " ".join(text.split())

    return text


def standardize_dataset(
    df: pd.DataFrame,
    dataset_name: str,
    text_col: str,
    label_col: str | None = None,
    label_map: dict | None = None,
    toxic_cols: list[str] | None = None,
) -> pd.DataFrame:
    """
    Padroniza qualquer dataset para:
    texto | rotulo | dataset

    Há duas formas de gerar o rótulo:
    1. Usando uma coluna de label única, via label_col + label_map.
    2. Usando várias colunas binárias de toxicidade, via toxic_cols.
    """

    df = df.copy()

    if text_col not in df.columns:
        raise ValueError(
            f"Coluna de texto '{text_col}' não encontrada em {dataset_name}. "
            f"Colunas disponíveis: {list(df.columns)}"
        )

    df["texto"] = df[text_col].apply(normalize_text)

    if toxic_cols:
        existing_cols = [col for col in toxic_cols if col in df.columns]

        if not existing_cols:
            raise ValueError(
                f"Nenhuma coluna de toxicidade encontrada em {dataset_name}. "
                f"Esperado algo entre: {toxic_cols}. "
                f"Colunas disponíveis: {list(df.columns)}"
            )

        df["rotulo"] = df[existing_cols].fillna(0).astype(int).max(axis=1)

    else:
        if label_col is None:
            raise ValueError("Informe label_col ou toxic_cols.")

        if label_col not in df.columns:
            raise ValueError(
                f"Coluna de rótulo '{label_col}' não encontrada em {dataset_name}. "
                f"Colunas disponíveis: {list(df.columns)}"
            )

        if label_map is None:
            raise ValueError("Informe label_map para converter os rótulos.")

        df["rotulo"] = df[label_col].map(label_map)

    df = df[["texto", "rotulo"]].copy()
    df["dataset"] = dataset_name

    df = df.dropna(subset=["texto", "rotulo"])
    df = df[df["texto"].str.len() > 0]
    df["rotulo"] = df["rotulo"].astype(int)

    return df.reset_index(drop=True)


def save_processed_dataset(df: pd.DataFrame, filename: str = "datasets_unificados.csv") -> None:
    DATA_PROCESSED.mkdir(parents=True, exist_ok=True)
    output_path = DATA_PROCESSED / filename
    df.to_csv(output_path, index=False, encoding="utf-8")
    print(f"Arquivo salvo em: {output_path}")