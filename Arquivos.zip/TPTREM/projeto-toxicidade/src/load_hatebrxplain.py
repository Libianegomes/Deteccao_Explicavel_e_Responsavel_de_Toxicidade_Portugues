from pathlib import Path

import pandas as pd


DATA_PROCESSED = Path("data/processed")


def carregar_hatebrxplain() -> pd.DataFrame:
    """
    Carrega o HateBRXplain diretamente do GitHub e padroniza para:
    texto | rotulo | dataset

    rotulo:
    1 = ofensivo/tóxico
    0 = não ofensivo/não tóxico
    """

    url = "https://raw.githubusercontent.com/franciellevargas/HateBR/main/dataset/HateBRXplain.csv"

    df = pd.read_csv(url)

    print("Colunas originais:")
    print(df.columns)
    print("\nFormato original:", df.shape)
    print("\nPrimeiras linhas:")
    print(df.head())

    colunas_obrigatorias = ["comment", "offensive_label"]

    for coluna in colunas_obrigatorias:
        if coluna not in df.columns:
            raise ValueError(
                f"Coluna '{coluna}' não encontrada. "
                f"Colunas disponíveis: {list(df.columns)}"
            )

    df["texto"] = df["comment"].astype(str).str.strip()
    df["rotulo"] = df["offensive_label"].astype(int)

    df_final = df[["texto", "rotulo"]].copy()
    df_final["dataset"] = "HateBRXplain"

    df_final = df_final.dropna()
    df_final = df_final[df_final["texto"].str.len() > 0]
    df_final = df_final.drop_duplicates(subset=["texto"])
    df_final = df_final.reset_index(drop=True)

    return df_final


if __name__ == "__main__":
    DATA_PROCESSED.mkdir(parents=True, exist_ok=True)

    df_hate = carregar_hatebrxplain()

    print("\nDataset processado:")
    print(df_hate.head())

    print("\nQuantidade de exemplos:")
    print(len(df_hate))

    print("\nDistribuição dos rótulos:")
    print(df_hate["rotulo"].value_counts())

    print("\nProporção dos rótulos:")
    print(df_hate["rotulo"].value_counts(normalize=True))

    output_path = DATA_PROCESSED / "hatebrxplain_processado.csv"
    df_hate.to_csv(output_path, index=False, encoding="utf-8")

    print(f"\nArquivo salvo em: {output_path}")