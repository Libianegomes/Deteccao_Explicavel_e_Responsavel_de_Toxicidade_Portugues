from pathlib import Path
import os
import json
import time

import pandas as pd
from dotenv import load_dotenv
from google import genai
from google.genai import types
from sklearn.metrics import accuracy_score, f1_score, classification_report


DATA_PROCESSED = Path("data/processed")
RESULTS_DIR = Path("results")

MODEL_NAME = "gemini-2.5-flash"


def carregar_dados() -> pd.DataFrame:
    path = DATA_PROCESSED / "datasets_unificados.csv"

    if not path.exists():
        raise FileNotFoundError(
            f"Arquivo não encontrado: {path}. "
            "Execute antes src/unificar_datasets.py."
        )

    df = pd.read_csv(path)
    df = df.dropna(subset=["texto", "rotulo", "dataset"])
    df["texto"] = df["texto"].astype(str)
    df["rotulo"] = df["rotulo"].astype(int)

    return df


def criar_amostra(df: pd.DataFrame, n_por_dataset: int = 40) -> pd.DataFrame:
    """
    Cria uma amostra pequena para reduzir custo e tempo.
    Tenta manter exemplos tóxicos e não tóxicos por dataset.
    """

    amostras = []

    for dataset in sorted(df["dataset"].unique()):
        df_dataset = df[df["dataset"] == dataset]

        for rotulo in [0, 1]:
            df_classe = df_dataset[df_dataset["rotulo"] == rotulo]

            n = min(n_por_dataset // 2, len(df_classe))

            if n > 0:
                amostras.append(
                    df_classe.sample(n=n, random_state=42)
                )

    df_amostra = pd.concat(amostras, ignore_index=True)
    df_amostra = df_amostra.sample(frac=1, random_state=42).reset_index(drop=True)

    return df_amostra


def montar_prompt(texto: str) -> str:
    return f"""
Você é um classificador de toxicidade em português brasileiro.

Classifique o texto abaixo como:
- 1 para tóxico/ofensivo
- 0 para não tóxico/não ofensivo

Também forneça uma justificativa curta, indicando quais termos, expressões ou elementos contextuais influenciaram sua decisão.

Responda obrigatoriamente em JSON válido, neste formato:
{{
  "rotulo_predito": 0,
  "justificativa": "explicação curta"
}}

Texto:
\"\"\"{texto}\"\"\"
""".strip()


def extrair_json(resposta_texto: str) -> dict:
    """
    Tenta interpretar a resposta do Gemini como JSON.
    Se houver texto antes/depois, tenta localizar o bloco JSON.
    """

    resposta_texto = resposta_texto.strip()

    try:
        return json.loads(resposta_texto)
    except json.JSONDecodeError:
        pass

    inicio = resposta_texto.find("{")
    fim = resposta_texto.rfind("}")

    if inicio != -1 and fim != -1 and fim > inicio:
        bloco = resposta_texto[inicio:fim + 1]
        return json.loads(bloco)

    raise ValueError(f"Não foi possível extrair JSON da resposta: {resposta_texto}")


def classificar_com_gemini(client, texto: str, max_tentativas: int = 5) -> dict:
    """
    Classifica um texto com o Gemini.
    Se ocorrer erro 429, tenta novamente com espera progressiva.
    """

    prompt = montar_prompt(texto)

    for tentativa in range(1, max_tentativas + 1):
        try:
            response = client.models.generate_content(
                model=MODEL_NAME,
                contents=prompt,
                config=types.GenerateContentConfig(
                    temperature=0,
                    response_mime_type="application/json",
                ),
            )

            dados = extrair_json(response.text)

            rotulo_predito = int(dados.get("rotulo_predito"))
            justificativa = str(dados.get("justificativa", "")).strip()

            if rotulo_predito not in [0, 1]:
                raise ValueError(f"Rótulo inválido retornado pelo Gemini: {rotulo_predito}")

            return {
                "rotulo_predito": rotulo_predito,
                "justificativa": justificativa,
            }

        except Exception as e:
            erro = str(e)

            print(f"Erro na tentativa {tentativa}/{max_tentativas}: {erro}")

            if "429" in erro or "RESOURCE_EXHAUSTED" in erro:
                espera = 30 * tentativa
                print(f"Aguardando {espera} segundos antes de tentar novamente...")
                time.sleep(espera)
            else:
                raise e

    raise RuntimeError(
        "Não foi possível classificar o texto após várias tentativas. "
        "Provável limite de quota da API Gemini."
    )


def avaliar_resultados(df_resultados: pd.DataFrame) -> pd.DataFrame:
    linhas = []

    for dataset in sorted(df_resultados["dataset"].unique()):
        df_dataset = df_resultados[df_resultados["dataset"] == dataset]

        y_true = df_dataset["rotulo"]
        y_pred = df_dataset["rotulo_predito"]

        linhas.append(
            {
                "modelo": "Gemini zero-shot",
                "dataset": dataset,
                "n": len(df_dataset),
                "acuracia": round(accuracy_score(y_true, y_pred), 4),
                "f1_macro": round(f1_score(y_true, y_pred, average="macro"), 4),
                "f1_toxico": round(f1_score(y_true, y_pred, pos_label=1), 4),
            }
        )

        print("=" * 80)
        print(f"Dataset: {dataset}")
        print(classification_report(y_true, y_pred, digits=4))

    y_true = df_resultados["rotulo"]
    y_pred = df_resultados["rotulo_predito"]

    linhas.append(
        {
            "modelo": "Gemini zero-shot",
            "dataset": "Todos",
            "n": len(df_resultados),
            "acuracia": round(accuracy_score(y_true, y_pred), 4),
            "f1_macro": round(f1_score(y_true, y_pred, average="macro"), 4),
            "f1_toxico": round(f1_score(y_true, y_pred, pos_label=1), 4),
        }
    )

    return pd.DataFrame(linhas)


def main():
    load_dotenv()

    api_key = os.getenv("GEMINI_API_KEY")

    if not api_key:
        raise ValueError(
            "GEMINI_API_KEY não encontrada. "
            "Crie um arquivo .env com GEMINI_API_KEY=SUA_CHAVE."
        )

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    client = genai.Client(api_key=api_key)

    df = carregar_dados()
    df_amostra = criar_amostra(df, n_por_dataset=4)

    print("Amostra selecionada:")
    print(df_amostra["dataset"].value_counts())
    print(pd.crosstab(df_amostra["dataset"], df_amostra["rotulo"]))

    resultados = []

    for idx, row in df_amostra.iterrows():
        print(f"Classificando {idx + 1}/{len(df_amostra)}...")

        try:
            predicao = classificar_com_gemini(client, row["texto"])

            resultados.append(
                {
                    "texto": row["texto"],
                    "dataset": row["dataset"],
                    "rotulo": row["rotulo"],
                    "rotulo_predito": predicao["rotulo_predito"],
                    "justificativa": predicao["justificativa"],
                    "erro": "",
                }
            )

        except Exception as e:
            resultados.append(
                {
                    "texto": row["texto"],
                    "dataset": row["dataset"],
                    "rotulo": row["rotulo"],
                    "rotulo_predito": None,
                    "justificativa": "",
                    "erro": str(e),
                }
            )

        time.sleep(15)

    df_resultados = pd.DataFrame(resultados)

    output_predicoes = RESULTS_DIR / "gemini_zero_shot_predicoes.csv"
    df_resultados.to_csv(output_predicoes, index=False, encoding="utf-8")

    print(f"\nPredições salvas em: {output_predicoes}")

    df_validos = df_resultados.dropna(subset=["rotulo_predito"]).copy()
    df_validos["rotulo_predito"] = df_validos["rotulo_predito"].astype(int)

    df_metricas = avaliar_resultados(df_validos)

    output_metricas = RESULTS_DIR / "gemini_zero_shot_metricas.csv"
    df_metricas.to_csv(output_metricas, index=False, encoding="utf-8")

    print(f"\nMétricas salvas em: {output_metricas}")
    print("\nResumo:")
    print(df_metricas)


if __name__ == "__main__":
    main()