from __future__ import annotations

import argparse
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

from sklearn.decomposition import TruncatedSVD
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, f1_score, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

try:
    from xgboost import XGBClassifier
except Exception:
    XGBClassifier = None


DATA_PROCESSED = Path("data/processed")
RESULTS_DIR = Path("results")
ARQUIVO_FEATURES = DATA_PROCESSED / "features_tabulares_lexicos.csv"

COLUNAS_CONTROLE = {"texto", "rotulo", "dataset"}
RANDOM_STATE = 42


def carregar_dados(max_linhas_por_dataset: Optional[int] = None) -> pd.DataFrame:
    print("Carregando dados...", flush=True)

    if not ARQUIVO_FEATURES.exists():
        raise FileNotFoundError(
            f"Arquivo não encontrado: {ARQUIVO_FEATURES}\n"
            "Execute antes os scripts de preparação e extração de features."
        )

    df = pd.read_csv(ARQUIVO_FEATURES)

    colunas_esperadas = {"texto", "rotulo", "dataset"}
    if not colunas_esperadas.issubset(df.columns):
        raise ValueError(
            f"O arquivo precisa conter as colunas {colunas_esperadas}.\n"
            f"Colunas encontradas: {list(df.columns)}"
        )

    df = df.dropna(subset=["texto", "rotulo", "dataset"]).copy()

    df["texto"] = df["texto"].astype(str)
    df["rotulo"] = df["rotulo"].astype(int)
    df["dataset"] = df["dataset"].astype(str)

    if max_linhas_por_dataset is not None:
        partes = []

        for _, grupo in df.groupby("dataset"):
            qtd = min(len(grupo), max_linhas_por_dataset)
            partes.append(
                grupo.sample(
                    n=qtd,
                    random_state=RANDOM_STATE,
                )
            )

        df = pd.concat(partes, ignore_index=True)
    else:
        df = df.reset_index(drop=True)

    print("Dados carregados com sucesso.", flush=True)
    print(f"Total de linhas: {len(df)}", flush=True)
    print("Quantidade por dataset:", flush=True)
    print(df["dataset"].value_counts(), flush=True)

    return df


def obter_colunas_tabulares(df: pd.DataFrame) -> List[str]:
    colunas = [col for col in df.columns if col not in COLUNAS_CONTROLE]

    if not colunas:
        raise ValueError("Nenhuma coluna tabular foi encontrada.")

    return colunas


def matriz_tabular(df: pd.DataFrame, colunas_tabulares: List[str]) -> np.ndarray:
    matriz = (
        df[colunas_tabulares]
        .apply(pd.to_numeric, errors="coerce")
        .fillna(0)
        .to_numpy(dtype=np.float32)
    )

    return matriz


def criar_modelos(nomes_modelos: Optional[Iterable[str]] = None) -> Dict[str, object]:
    modelos: Dict[str, object] = {
        "Regressao Logistica": Pipeline(
            steps=[
                ("scaler", StandardScaler()),
                (
                    "clf",
                    LogisticRegression(
                        max_iter=2000,
                        class_weight="balanced",
                        random_state=RANDOM_STATE,
                    ),
                ),
            ]
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=300,
            class_weight="balanced",
            random_state=RANDOM_STATE,
            n_jobs=-1,
        ),
        "Gradient Boosting": GradientBoostingClassifier(
            random_state=RANDOM_STATE,
        ),
    }

    if XGBClassifier is not None:
        modelos["XGBoost"] = XGBClassifier(
            n_estimators=300,
            max_depth=4,
            learning_rate=0.05,
            subsample=0.8,
            colsample_bytree=0.8,
            objective="binary:logistic",
            eval_metric="logloss",
            random_state=RANDOM_STATE,
            n_jobs=-1,
        )

    if nomes_modelos:
        nomes = {nome.strip() for nome in nomes_modelos if nome.strip()}
        modelos_filtrados = {
            nome: modelo for nome, modelo in modelos.items() if nome in nomes
        }

        if not modelos_filtrados:
            raise ValueError(
                "Nenhum modelo válido foi selecionado.\n"
                "Opções disponíveis: "
                "Regressao Logistica, Random Forest, Gradient Boosting, XGBoost."
            )

        modelos = modelos_filtrados

    return modelos


def avaliar_modelo(modelo, x_train, y_train, x_test, y_test) -> Dict[str, object]:
    modelo.fit(x_train, y_train)

    y_pred = modelo.predict(x_test)

    auc = None

    try:
        y_proba = modelo.predict_proba(x_test)[:, 1]
        auc = roc_auc_score(y_test, y_proba)
    except Exception:
        auc = None

    return {
        "acuracia": round(accuracy_score(y_test, y_pred), 4),
        "f1_macro": round(f1_score(y_test, y_pred, average="macro"), 4),
        "f1_toxico": round(f1_score(y_test, y_pred, pos_label=1), 4),
        "auc_roc": round(auc, 4) if auc is not None else None,
        "classification_report": classification_report(
            y_test,
            y_pred,
            digits=4,
            zero_division=0,
        ),
    }


def criar_tfidf_svd(
    textos_treino: pd.Series,
    textos_teste: pd.Series,
    n_componentes: int,
) -> Tuple[np.ndarray, np.ndarray]:
    tfidf = TfidfVectorizer(
        lowercase=True,
        ngram_range=(1, 2),
        min_df=2,
        max_df=0.95,
        sublinear_tf=True,
        max_features=50000,
    )

    x_train_tfidf = tfidf.fit_transform(textos_treino)
    x_test_tfidf = tfidf.transform(textos_teste)

    limite_componentes = min(
        n_componentes,
        x_train_tfidf.shape[1] - 1,
        x_train_tfidf.shape[0] - 1,
    )

    if limite_componentes < 2:
        return (
            x_train_tfidf.toarray().astype(np.float32),
            x_test_tfidf.toarray().astype(np.float32),
        )

    svd = TruncatedSVD(
        n_components=limite_componentes,
        random_state=RANDOM_STATE,
    )

    x_train = svd.fit_transform(x_train_tfidf).astype(np.float32)
    x_test = svd.transform(x_test_tfidf).astype(np.float32)

    return x_train, x_test


def gerar_embeddings(
    df: pd.DataFrame,
    nome_modelo: str,
    batch_size: int,
) -> np.ndarray:
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError as exc:
        raise ImportError(
            "A biblioteca sentence-transformers não está instalada.\n"
            "Instale com: pip install sentence-transformers"
        ) from exc

    print(f"Carregando modelo de embeddings: {nome_modelo}", flush=True)

    modelo = SentenceTransformer(nome_modelo)

    print("Gerando embeddings dos textos...", flush=True)

    embeddings = modelo.encode(
        df["texto"].tolist(),
        batch_size=batch_size,
        show_progress_bar=True,
        convert_to_numpy=True,
        normalize_embeddings=True,
    )

    print("Embeddings gerados com sucesso.", flush=True)

    return embeddings.astype(np.float32)


def executar_cross_dataset(
    df: pd.DataFrame,
    modelos: Dict[str, object],
    usar_embeddings: bool,
    nome_modelo_embeddings: str,
    batch_size: int,
    n_componentes_svd: int,
) -> pd.DataFrame:
    colunas_tabulares = obter_colunas_tabulares(df)

    print(f"Total de features tabulares: {len(colunas_tabulares)}", flush=True)

    x_tabular_todas = matriz_tabular(df, colunas_tabulares)

    embeddings_todos = None

    if usar_embeddings:
        embeddings_todos = gerar_embeddings(
            df=df,
            nome_modelo=nome_modelo_embeddings,
            batch_size=batch_size,
        )

    datasets = sorted(df["dataset"].unique())

    print("Datasets encontrados:", datasets, flush=True)

    resultados = []

    for dataset_treino in datasets:
        for dataset_teste in datasets:
            if dataset_treino == dataset_teste:
                continue

            idx_train = df.index[df["dataset"] == dataset_treino].to_numpy()
            idx_test = df.index[df["dataset"] == dataset_teste].to_numpy()

            df_train = df.loc[idx_train]
            df_test = df.loc[idx_test]

            y_train = df_train["rotulo"].to_numpy()
            y_test = df_test["rotulo"].to_numpy()

            representacoes = {}

            representacoes["Tabular"] = (
                x_tabular_todas[idx_train],
                x_tabular_todas[idx_test],
            )

            print(
                f"Criando TF-IDF/SVD para {dataset_treino} -> {dataset_teste}...",
                flush=True,
            )

            representacoes["Nao tabular - TF-IDF/SVD"] = criar_tfidf_svd(
                textos_treino=df_train["texto"],
                textos_teste=df_test["texto"],
                n_componentes=n_componentes_svd,
            )

            if usar_embeddings and embeddings_todos is not None:
                x_emb_train = embeddings_todos[idx_train]
                x_emb_test = embeddings_todos[idx_test]

                representacoes["Nao tabular - Embedding"] = (
                    x_emb_train,
                    x_emb_test,
                )

                representacoes["Hibrida - Tabular + Embedding"] = (
                    np.hstack(
                        [
                            x_tabular_todas[idx_train],
                            x_emb_train,
                        ]
                    ).astype(np.float32),
                    np.hstack(
                        [
                            x_tabular_todas[idx_test],
                            x_emb_test,
                        ]
                    ).astype(np.float32),
                )

            for nome_representacao, (x_train, x_test) in representacoes.items():
                for nome_modelo in modelos.keys():
                    modelo = criar_modelos([nome_modelo])[nome_modelo]

                    print("=" * 80, flush=True)
                    print(
                        f"Representação: {nome_representacao} | "
                        f"Modelo: {nome_modelo} | "
                        f"Treino: {dataset_treino} | "
                        f"Teste: {dataset_teste}",
                        flush=True,
                    )

                    metricas = avaliar_modelo(
                        modelo=modelo,
                        x_train=x_train,
                        y_train=y_train,
                        x_test=x_test,
                        y_test=y_test,
                    )

                    print(metricas["classification_report"], flush=True)

                    resultados.append(
                        {
                            "representacao": nome_representacao,
                            "modelo": nome_modelo,
                            "treino": dataset_treino,
                            "teste": dataset_teste,
                            "n_treino": len(df_train),
                            "n_teste": len(df_test),
                            "acuracia": metricas["acuracia"],
                            "f1_macro": metricas["f1_macro"],
                            "f1_toxico": metricas["f1_toxico"],
                            "auc_roc": metricas["auc_roc"],
                        }
                    )

    return pd.DataFrame(resultados)


def salvar_resultados(df_resultados: pd.DataFrame) -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    caminho_resultados = RESULTS_DIR / "representacoes_cross_dataset.csv"

    df_resultados.to_csv(
        caminho_resultados,
        index=False,
        encoding="utf-8",
    )

    print(f"Resultados completos salvos em: {caminho_resultados}", flush=True)

    resumo = (
        df_resultados.groupby(["representacao", "modelo"])
        .agg(
            media_f1_macro=("f1_macro", "mean"),
            desvio_f1_macro=("f1_macro", "std"),
            media_acuracia=("acuracia", "mean"),
            media_auc_roc=("auc_roc", "mean"),
        )
        .reset_index()
        .sort_values(by="media_f1_macro", ascending=False)
        .round(4)
    )

    caminho_resumo = RESULTS_DIR / "resumo_representacoes_por_modelo.csv"

    resumo.to_csv(
        caminho_resumo,
        index=False,
        encoding="utf-8",
    )

    print(f"Resumo salvo em: {caminho_resumo}", flush=True)

    melhores = df_resultados.copy()
    melhores["cenario"] = melhores["treino"] + " -> " + melhores["teste"]

    melhores = (
        melhores.sort_values(
            by=["cenario", "f1_macro"],
            ascending=[True, False],
        )
        .groupby("cenario")
        .head(1)
        .reset_index(drop=True)
    )

    caminho_melhores = RESULTS_DIR / "melhor_representacao_por_cenario.csv"

    melhores.to_csv(
        caminho_melhores,
        index=False,
        encoding="utf-8",
    )

    print(f"Melhor configuração por cenário salva em: {caminho_melhores}", flush=True)

    print("\nResumo por representação e modelo:", flush=True)
    print(resumo, flush=True)

    print("\nMelhor configuração por cenário:", flush=True)
    print(
        melhores[
            [
                "cenario",
                "representacao",
                "modelo",
                "f1_macro",
                "acuracia",
                "auc_roc",
            ]
        ],
        flush=True,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Compara representações tabulares, não tabulares e híbridas "
            "em avaliação cross-dataset."
        )
    )

    parser.add_argument(
        "--sem_embeddings",
        action="store_true",
        help="Executa apenas Tabular e TF-IDF/SVD, sem gerar embeddings.",
    )

    parser.add_argument(
        "--modelo_embeddings",
        default="sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
        help="Modelo usado para gerar embeddings com SentenceTransformers.",
    )

    parser.add_argument(
        "--batch_size",
        type=int,
        default=64,
        help="Tamanho do lote usado na geração de embeddings.",
    )

    parser.add_argument(
        "--svd_componentes",
        type=int,
        default=300,
        help="Número máximo de componentes da redução SVD aplicada ao TF-IDF.",
    )

    parser.add_argument(
        "--max_linhas_por_dataset",
        type=int,
        default=None,
        help="Limita a quantidade de exemplos por dataset para testes rápidos.",
    )

    parser.add_argument(
        "--modelos",
        default=None,
        help=(
            "Lista de modelos separados por vírgula. "
            "Exemplo: 'Regressao Logistica,Random Forest'."
        ),
    )

    return parser.parse_args()


def main() -> None:
    args = parse_args()

    nomes_modelos = None

    if args.modelos:
        nomes_modelos = [nome.strip() for nome in args.modelos.split(",")]

    df = carregar_dados(
        max_linhas_por_dataset=args.max_linhas_por_dataset,
    )

    modelos = criar_modelos(nomes_modelos)

    print("\nModelos selecionados:", flush=True)
    print(list(modelos.keys()), flush=True)

    df_resultados = executar_cross_dataset(
        df=df,
        modelos=modelos,
        usar_embeddings=not args.sem_embeddings,
        nome_modelo_embeddings=args.modelo_embeddings,
        batch_size=args.batch_size,
        n_componentes_svd=args.svd_componentes,
    )

    salvar_resultados(df_resultados)


if __name__ == "__main__":
    main()