from pathlib import Path

import pandas as pd


RESULTS_DIR = Path("results")


def main():
    path_modelos = RESULTS_DIR / "resumo_por_modelo.csv"
    path_gemini = RESULTS_DIR / "gemini_zero_shot_metricas.csv"

    if not path_modelos.exists():
        raise FileNotFoundError(
            f"Arquivo não encontrado: {path_modelos}. "
            "Execute antes src/gerar_resumo_resultados.py."
        )

    if not path_gemini.exists():
        raise FileNotFoundError(
            f"Arquivo não encontrado: {path_gemini}. "
            "Execute antes src/avaliar_gemini.py."
        )

    df_modelos = pd.read_csv(path_modelos)
    df_gemini = pd.read_csv(path_gemini)

    print("Resumo dos modelos tradicionais:")
    print(df_modelos)

    print("\nMétricas do Gemini:")
    print(df_gemini)

    # Usa a linha geral do Gemini, se existir.
    if "Todos" in df_gemini["dataset"].values:
        gemini_geral = df_gemini[df_gemini["dataset"] == "Todos"].copy()
    else:
        gemini_geral = df_gemini.copy()

    gemini_resumo = pd.DataFrame(
        {
            "modelo": ["Gemini zero-shot"],
            "media_f1_macro": [gemini_geral["f1_macro"].mean()],
            "desvio_f1_macro": [None],
            "media_acuracia": [gemini_geral["acuracia"].mean()],
            "media_auc_roc": [None],
        }
    )

    df_comparacao = pd.concat(
        [
            df_modelos,
            gemini_resumo,
        ],
        ignore_index=True,
    )

    df_comparacao = df_comparacao.sort_values(
        by="media_f1_macro",
        ascending=False,
    ).round(4)

    output_path = RESULTS_DIR / "comparacao_modelos_gemini.csv"
    df_comparacao.to_csv(output_path, index=False, encoding="utf-8")

    print("\nComparação final:")
    print(df_comparacao)

    print(f"\nArquivo salvo em: {output_path}")


if __name__ == "__main__":
    main()