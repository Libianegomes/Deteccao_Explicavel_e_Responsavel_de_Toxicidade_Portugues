from pathlib import Path
from collections import Counter, defaultdict
import re
import unicodedata

import pandas as pd


DATA_PROCESSED = Path("data/processed")
DATA_LEXICONS = Path("data/raw/lexicons")


HURTLEX_URL = "https://raw.githubusercontent.com/valeriobasile/hurtlex/master/lexica/PT/1.2/hurtlex_PT.tsv"
MOL_URL = "https://raw.githubusercontent.com/franciellevargas/MOL/refs/heads/main/data/mol.csv"


def normalizar_texto(texto: str) -> str:
    texto = str(texto).lower()
    texto = unicodedata.normalize("NFKD", texto)
    texto = "".join(char for char in texto if not unicodedata.combining(char))
    texto = re.sub(r"\s+", " ", texto)
    return texto.strip()


def tokenizar(texto: str) -> list[str]:
    texto = normalizar_texto(texto)
    return re.findall(r"\b\w+\b", texto)


def carregar_hurtlex() -> dict:
    """
    Carrega o HurtLex em português diretamente do arquivo:
    lexica/PT/1.2/hurtlex_PT.tsv

    Retorna:
    termo_normalizado -> conjunto de categorias HurtLex
    """

    print("Carregando HurtLex PT...")

    df = pd.read_csv(HURTLEX_URL, sep="\t", dtype=str)
    df.columns = [col.strip().lower() for col in df.columns]

    print("Colunas HurtLex:")
    print(df.columns.tolist())

    # No HurtLex PT, normalmente as colunas relevantes são:
    # lemma, category, stereotype, level
    termo_col = None
    for col in ["lemma", "term", "word", "palavra"]:
        if col in df.columns:
            termo_col = col
            break

    categoria_col = None
    for col in ["category", "cat", "classe", "label"]:
        if col in df.columns:
            categoria_col = col
            break

    if termo_col is None:
        raise ValueError(
            "Não consegui identificar a coluna do termo no HurtLex PT. "
            f"Colunas encontradas: {df.columns.tolist()}"
        )

    if categoria_col is None:
        raise ValueError(
            "Não consegui identificar a coluna de categoria no HurtLex PT. "
            f"Colunas encontradas: {df.columns.tolist()}"
        )

    termo_para_categorias = defaultdict(set)

    for _, row in df.iterrows():
        termo = row.get(termo_col)
        categoria = row.get(categoria_col)

        if pd.isna(termo) or pd.isna(categoria):
            continue

        termo_norm = normalizar_texto(termo)
        categoria_norm = str(categoria).strip().lower()

        if termo_norm and categoria_norm:
            termo_para_categorias[termo_norm].add(categoria_norm)

    print(f"Termos HurtLex PT carregados: {len(termo_para_categorias)}")

    return dict(termo_para_categorias)

def carregar_mol() -> tuple[dict, list[tuple[str, str]]]:
    """
    Carrega o MOL e separa:
    - termos de uma palavra;
    - expressões com múltiplas palavras.

    Retorna:
    mol_termos_simples: termo -> classe contextual
    mol_expressoes: lista de (expressao, classe contextual)
    """

    print("Carregando MOL...")

    df = pd.read_csv(MOL_URL, dtype=str)

    df.columns = [
        col.strip()
        .lower()
        .replace("–", "-")
        .replace("—", "-")
        .replace("_", "-")
        for col in df.columns
    ]

    print("Colunas MOL normalizadas:")
    print(df.columns.tolist())

    # Esta é a coluna correta com os termos em português brasileiro.
    termo_col = "pt-brazilian-portuguese"

    if termo_col not in df.columns:
        raise ValueError(
            f"Coluna '{termo_col}' não encontrada no MOL. "
            f"Colunas encontradas: {df.columns.tolist()}"
        )

    classe_col = "pt-contextual-label"

    if classe_col not in df.columns:
        classe_col = None

    hate_col = "pt-hate-label"

    if hate_col not in df.columns:
        hate_col = None

    print(f"Coluna de termo identificada: {termo_col}")
    print(f"Coluna contextual identificada: {classe_col}")
    print(f"Coluna de hate label identificada: {hate_col}")

    mol_termos_simples = {}
    mol_expressoes = []

    for _, row in df.iterrows():
        termo = row.get(termo_col)

        if pd.isna(termo):
            continue

        termo_norm = normalizar_texto(termo)

        if not termo_norm:
            continue

        classe = "mol"

        if classe_col is not None and not pd.isna(row.get(classe_col)):
            classe = normalizar_texto(row.get(classe_col))

        if len(termo_norm.split()) == 1:
            mol_termos_simples[termo_norm] = classe
        else:
            mol_expressoes.append((termo_norm, classe))

    print(f"Termos simples MOL carregados: {len(mol_termos_simples)}")
    print(f"Expressões MOL carregadas: {len(mol_expressoes)}")

    return mol_termos_simples, mol_expressoes


def extrair_features_lexicas(
    texto: str,
    hurtlex: dict,
    mol_termos_simples: dict,
    mol_expressoes: list[tuple[str, str]],
) -> dict:
    tokens = tokenizar(texto)
    contagem_tokens = Counter(tokens)

    features = {}

    # HurtLex
    n_hurtlex = 0
    categorias_hurtlex = Counter()

    for token, qtd in contagem_tokens.items():
        if token in hurtlex:
            n_hurtlex += qtd

            for categoria in hurtlex[token]:
                categorias_hurtlex[categoria] += qtd

    features["n_hurtlex_terms"] = n_hurtlex
    features["has_hurtlex_term"] = int(n_hurtlex > 0)

    for categoria, qtd in categorias_hurtlex.items():
        nome_coluna = f"hurtlex_{categoria}".lower().replace(" ", "_")
        features[nome_coluna] = qtd

    # MOL
    n_mol = 0
    n_mol_context_independent = 0
    n_mol_context_dependent = 0

    for token, qtd in contagem_tokens.items():
        if token in mol_termos_simples:
            n_mol += qtd
            classe = mol_termos_simples[token]

            if classe in {"1", "independent", "context-independent", "context independent"}:
                n_mol_context_independent += qtd
            elif classe in {"0", "dependent", "context-dependent", "context dependent"}:
                n_mol_context_dependent += qtd

    texto_norm = normalizar_texto(texto)

    for expressao, classe in mol_expressoes:
        padrao = r"\b" + re.escape(expressao) + r"\b"
        ocorrencias = len(re.findall(padrao, texto_norm))

        if ocorrencias > 0:
            n_mol += ocorrencias

            if classe in {"1", "independent", "context-independent", "context independent"}:
                n_mol_context_independent += ocorrencias
            elif classe in {"0", "dependent", "context-dependent", "context dependent"}:
                n_mol_context_dependent += ocorrencias

    features["n_mol_terms"] = n_mol
    features["has_mol_term"] = int(n_mol > 0)
    features["n_mol_context_independent"] = n_mol_context_independent
    features["n_mol_context_dependent"] = n_mol_context_dependent

    return features




def main():
    input_path = DATA_PROCESSED / "features_tabulares.csv"

    if not input_path.exists():
        raise FileNotFoundError(
            f"Arquivo não encontrado: {input_path}. "
            "Execute antes src/criar_features_tabulares.py."
        )

    df = pd.read_csv(input_path)

    print("Arquivo de entrada:")
    print(df.head())

    hurtlex = carregar_hurtlex()
    mol_termos_simples, mol_expressoes = carregar_mol()

    features = df["texto"].apply(
        lambda texto: extrair_features_lexicas(
            texto=texto,
            hurtlex=hurtlex,
            mol_termos_simples=mol_termos_simples,
            mol_expressoes=mol_expressoes,
        )
    )

    df_features_lexicas = pd.DataFrame(features.tolist()).fillna(0)

    df_saida = pd.concat(
        [
            df.reset_index(drop=True),
            df_features_lexicas.reset_index(drop=True),
        ],
        axis=1,
    )

    # Remove colunas duplicadas, caso existam.
    df_saida = df_saida.loc[:, ~df_saida.columns.duplicated()].copy()

    # Garante que todas as features sejam numéricas,
    # preservando texto, rótulo e dataset.
    colunas_base = {"texto", "rotulo", "dataset"}

    for col in df_saida.columns:
        if col not in colunas_base:
            serie = df_saida[col]

            if isinstance(serie, pd.DataFrame):
                serie = serie.iloc[:, 0]

            df_saida[col] = pd.to_numeric(serie, errors="coerce").fillna(0)

    output_path = DATA_PROCESSED / "features_tabulares_lexicos.csv"
    df_saida.to_csv(output_path, index=False, encoding="utf-8")

    print("\nArquivo com features léxicas salvo em:")
    print(output_path)

    print("\nFormato final:")
    print(df_saida.shape)

    print("\nColunas finais:")
    print(df_saida.columns.tolist())

    novas_colunas = [col for col in df_features_lexicas.columns]

    print("\nResumo das novas features:")
    print(df_saida[novas_colunas].sum().sort_values(ascending=False).head(20))


if __name__ == "__main__":
    main()