from pathlib import Path

import pandas as pd

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, classification_report


DATA_PROCESSED = Path("data/processed")
RESULTS_DIR = Path("results")


def carregar_dados() -> pd.DataFrame:
    path = DATA_PROCESSED / "datasets_unificados.csv"

    if not path.exists():
        raise FileNotFoundError(
            f"Arquivo não encontrado: {path}. "
            "Execute antes o script src/unificar_datasets.py."
        )

    df = pd.read_csv(path)

    colunas_esperadas = {"texto", "rotulo", "dataset"}
    if not colunas_esperadas.issubset(df.columns):
        raise ValueError(
            f"O arquivo precisa ter as colunas {colunas_esperadas}. "
            f"Colunas encontradas: {list(df.columns)}"
        )

    df = df.dropna(subset=["texto", "rotulo", "dataset"])
    df["texto"] = df["texto"].astype(str)
    df["rotulo"] = df["rotulo"].astype(int)

    return df


def criar_modelo():
    """
    Baseline inicial:
    TF-IDF + Regressão Logística.

    Este modelo é simples, rápido e serve para validar o pipeline.
    """
    modelo = Pipeline(
        steps=[
            (
                "tfidf",
                TfidfVectorizer(
                    lowercase=True,
                    ngram_range=(1, 2),
                    min_df=2,
                    max_df=0.95,
                    sublinear_tf=True,
                ),
            ),
            (
                "clf",
                LogisticRegression(
                    max_iter=1000,
                    class_weight="balanced",
                    random_state=42,
                ),
            ),
        ]
    )

    return modelo


def avaliar_cross_dataset(df: pd.DataFrame) -> pd.DataFrame:
    datasets = sorted(df["dataset"].unique())

    resultados = []

    for dataset_treino in datasets:
        for dataset_teste in datasets:
            if dataset_treino == dataset_teste:
                continue

            df_train = df[df["dataset"] == dataset_treino].copy()
            df_test = df[df["dataset"] == dataset_teste].copy()

            x_train = df_train["texto"]
            y_train = df_train["rotulo"]

            x_test = df_test["texto"]
            y_test = df_test["rotulo"]

            modelo = criar_modelo()
            modelo.fit(x_train, y_train)

            y_pred = modelo.predict(x_test)

            try:
                y_proba = modelo.predict_proba(x_test)[:, 1]
                auc = roc_auc_score(y_test, y_proba)
            except Exception:
                auc = None

            acc = accuracy_score(y_test, y_pred)
            f1_macro = f1_score(y_test, y_pred, average="macro")
            f1_toxico = f1_score(y_test, y_pred, pos_label=1)

            print("=" * 80)
            print(f"Treino: {dataset_treino} | Teste: {dataset_teste}")
            print(classification_report(y_test, y_pred, digits=4))

            resultados.append(
                {
                    "modelo": "TF-IDF + Regressao Logistica",
                    "treino": dataset_treino,
                    "teste": dataset_teste,
                    "n_treino": len(df_train),
                    "n_teste": len(df_test),
                    "acuracia": round(acc, 4),
                    "f1_macro": round(f1_macro, 4),
                    "f1_toxico": round(f1_toxico, 4),
                    "auc_roc": round(auc, 4) if auc is not None else None,
                }
            )

    return pd.DataFrame(resultados)


def main():
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    df = carregar_dados()

    print("Dados carregados:")
    print(df.head())

    print("\nQuantidade por dataset:")
    print(df["dataset"].value_counts())

    print("\nDistribuição dos rótulos por dataset:")
    print(pd.crosstab(df["dataset"], df["rotulo"]))

    resultados = avaliar_cross_dataset(df)

    print("\nResultados consolidados:")
    print(resultados)

    output_path = RESULTS_DIR / "baseline_cross_dataset.csv"
    resultados.to_csv(output_path, index=False, encoding="utf-8")

    print(f"\nResultados salvos em: {output_path}")


if __name__ == "__main__":
    main()