from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import shap

from xgboost import XGBClassifier
from sklearn.metrics import f1_score, accuracy_score, roc_auc_score


DATA_PROCESSED = Path("data/processed")
RESULTS_DIR = Path("results/explicabilidade_xgboost")
FIGURES_DIR = Path("reports/figures/explicabilidade_xgboost")


def carregar_dados() -> pd.DataFrame:
    path = DATA_PROCESSED / "features_tabulares_lexicos.csv"

    if not path.exists():
        raise FileNotFoundError(
            f"Arquivo não encontrado: {path}. "
            "Execute antes src/criar_features_tabulares.py."
        )

    df = pd.read_csv(path)

    colunas_esperadas = {"texto", "rotulo", "dataset"}
    if not colunas_esperadas.issubset(df.columns):
        raise ValueError(
            f"O arquivo precisa conter {colunas_esperadas}. "
            f"Colunas encontradas: {list(df.columns)}"
        )

    df = df.dropna(subset=["texto", "rotulo", "dataset"])
    df["rotulo"] = df["rotulo"].astype(int)

    return df


def obter_colunas_features(df: pd.DataFrame) -> list[str]:
    colunas_nao_features = {"texto", "rotulo", "dataset"}
    return [col for col in df.columns if col not in colunas_nao_features]


def criar_xgboost() -> XGBClassifier:
    return XGBClassifier(
        n_estimators=300,
        max_depth=4,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        objective="binary:logistic",
        eval_metric="logloss",
        random_state=42,
        n_jobs=-1,
    )


def salvar_importancia_features(modelo, feature_cols, nome_cenario):
    importancias = pd.DataFrame(
        {
            "feature": feature_cols,
            "importancia": modelo.feature_importances_,
        }
    ).sort_values(by="importancia", ascending=False)

    output_path = RESULTS_DIR / f"importancia_features_{nome_cenario}.csv"
    importancias.to_csv(output_path, index=False, encoding="utf-8")

    print(f"Importância de features salva em: {output_path}")

    return importancias


def gerar_grafico_importancia(importancias: pd.DataFrame, nome_cenario: str):
    top = importancias.head(15).sort_values(by="importancia", ascending=True)

    plt.figure(figsize=(10, 6))
    plt.barh(top["feature"], top["importancia"])
    plt.title(f"Top 15 features - XGBoost ({nome_cenario})")
    plt.xlabel("Importância")
    plt.ylabel("Feature")
    plt.tight_layout()

    output_path = FIGURES_DIR / f"importancia_features_{nome_cenario}.png"
    plt.savefig(output_path, dpi=300)
    plt.close()

    print(f"Gráfico de importância salvo em: {output_path}")


def gerar_shap(modelo, x_train, x_test, nome_cenario: str):
    """
    Gera gráfico global de SHAP para o XGBoost.
    Para evitar processamento excessivo, usa uma amostra do conjunto de teste.
    """

    n_amostra = min(300, len(x_test))
    x_sample = x_test.sample(n=n_amostra, random_state=42)

    explainer = shap.TreeExplainer(modelo)
    shap_values = explainer.shap_values(x_sample)

    plt.figure()
    shap.summary_plot(
        shap_values,
        x_sample,
        show=False,
        max_display=15,
    )

    output_path = FIGURES_DIR / f"shap_summary_{nome_cenario}.png"
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close()

    print(f"Gráfico SHAP salvo em: {output_path}")


def main():
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)

    df = carregar_dados()
    feature_cols = obter_colunas_features(df)

    datasets = sorted(df["dataset"].unique())

    print("Datasets encontrados:")
    print(datasets)

    print("\nFeatures usadas:")
    print(feature_cols)

    metricas_cenarios = []

    for dataset_treino in datasets:
        for dataset_teste in datasets:
            if dataset_treino == dataset_teste:
                continue

            print("=" * 80)
            print(f"Treino: {dataset_treino} | Teste: {dataset_teste}")

            df_train = df[df["dataset"] == dataset_treino].copy()
            df_test = df[df["dataset"] == dataset_teste].copy()

            x_train = df_train[feature_cols]
            y_train = df_train["rotulo"]

            x_test = df_test[feature_cols]
            y_test = df_test["rotulo"]

            modelo = criar_xgboost()
            modelo.fit(x_train, y_train)

            y_pred = modelo.predict(x_test)

            try:
                y_proba = modelo.predict_proba(x_test)[:, 1]
                auc = roc_auc_score(y_test, y_proba)
            except Exception:
                auc = np.nan

            f1_macro = f1_score(y_test, y_pred, average="macro")
            acuracia = accuracy_score(y_test, y_pred)

            nome_cenario = (
                f"{dataset_treino}_para_{dataset_teste}"
                .replace(" ", "_")
                .replace("-", "_")
            )

            importancias = salvar_importancia_features(
                modelo=modelo,
                feature_cols=feature_cols,
                nome_cenario=nome_cenario,
            )

            gerar_grafico_importancia(importancias, nome_cenario)
            gerar_shap(modelo, x_train, x_test, nome_cenario)

            metricas_cenarios.append(
                {
                    "treino": dataset_treino,
                    "teste": dataset_teste,
                    "modelo": "XGBoost",
                    "f1_macro": round(f1_macro, 4),
                    "acuracia": round(acuracia, 4),
                    "auc_roc": round(auc, 4) if not np.isnan(auc) else None,
                }
            )

    df_metricas = pd.DataFrame(metricas_cenarios)
    metricas_path = RESULTS_DIR / "metricas_xgboost_explicabilidade.csv"
    df_metricas.to_csv(metricas_path, index=False, encoding="utf-8")

    print("\nMétricas salvas em:")
    print(metricas_path)

    print("\nResumo:")
    print(df_metricas)


if __name__ == "__main__":
    main()