from pathlib import Path

import pandas as pd
from datasets import load_dataset


DATA_PROCESSED = Path("data/processed")


def carregar_olidbr() -> pd.DataFrame:
    """
    Carrega o OLID-BR via Hugging Face e padroniza para:
    texto | rotulo | dataset

    rotulo:
    1 = ofensivo/tóxico
    0 = não ofensivo/não tóxico
    """

    dataset = load_dataset("dougtrajano/olid-br")

    print("Splits encontrados:")
    print(dataset)

    # Normalmente o dataset possui split "train".
    split_name = "train" if "train" in dataset else list(dataset.keys())[0]

    df = dataset[split_name].to_pandas()

    print("\nColunas originais:")
    print(df.columns.tolist())

    print("\nFormato original:")
    print(df.shape)

    print("\nPrimeiras linhas:")
    print(df.head())

    if "text" not in df.columns:
        raise ValueError(
            f"Coluna 'text' não encontrada. Colunas disponíveis: {list(df.columns)}"
        )

    if "is_offensive" not in df.columns:
        raise ValueError(
            f"Coluna 'is_offensive' não encontrada. Colunas disponíveis: {list(df.columns)}"
        )

    label_map = {
        "OFF": 1,
        "NOT": 0,
        "off": 1,
        "not": 0,
        "Ofensivo": 1,
        "Não ofensivo": 0,
    }

    df["texto"] = df["text"].astype(str).str.strip()
    df["rotulo"] = df["is_offensive"].map(label_map)

    # Remove linhas com rótulo não reconhecido.
    df_final = df[["texto", "rotulo"]].copy()
    df_final["dataset"] = "OLID-BR"

    df_final = df_final.dropna(subset=["texto", "rotulo"])
    df_final = df_final[df_final["texto"].str.len() > 0]
    df_final = df_final.drop_duplicates(subset=["texto"])
    df_final["rotulo"] = df_final["rotulo"].astype(int)

    return df_final.reset_index(drop=True)


if __name__ == "__main__":
    DATA_PROCESSED.mkdir(parents=True, exist_ok=True)

    df_olid = carregar_olidbr()

    print("\nDataset processado:")
    print(df_olid.head())

    print("\nQuantidade de exemplos:")
    print(len(df_olid))

    print("\nDistribuição dos rótulos:")
    print(df_olid["rotulo"].value_counts())

    print("\nProporção dos rótulos:")
    print(df_olid["rotulo"].value_counts(normalize=True))

    output_path = DATA_PROCESSED / "olidbr_processado.csv"
    df_olid.to_csv(output_path, index=False, encoding="utf-8")

    print(f"\nArquivo salvo em: {output_path}")