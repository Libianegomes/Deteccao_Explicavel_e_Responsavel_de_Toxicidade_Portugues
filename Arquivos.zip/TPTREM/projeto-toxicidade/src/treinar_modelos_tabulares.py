from pathlib import Path

import pandas as pd

from xgboost import XGBClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    roc_auc_score,
    classification_report,
)



DATA_PROCESSED = Path("data/processed")
RESULTS_DIR = Path("results")


def carregar_features() -> pd.DataFrame:
    path = DATA_PROCESSED / "features_tabulares_lexicos.csv"

    if not path.exists():
        raise FileNotFoundError(
            f"Arquivo não encontrado: {path}. "
            "Execute antes o script src/criar_features_tabulares.py."
        )

    df = pd.read_csv(path)

    colunas_esperadas = {"texto", "rotulo", "dataset"}
    if not colunas_esperadas.issubset(df.columns):
        raise ValueError(
            f"O arquivo precisa ter as colunas {colunas_esperadas}. "
            f"Colunas encontradas: {list(df.columns)}"
        )

    df = df.dropna(subset=["texto", "rotulo", "dataset"])
    df["rotulo"] = df["rotulo"].astype(int)

    return df


def obter_colunas_features(df: pd.DataFrame) -> list[str]:
    colunas_nao_features = {"texto", "rotulo", "dataset"}
    return [col for col in df.columns if col not in colunas_nao_features]


def criar_modelos():
    modelos = {
        "Regressao Logistica": Pipeline(
            steps=[
                ("scaler", StandardScaler()),
                (
                    "clf",
                    LogisticRegression(
                        max_iter=1000,
                        class_weight="balanced",
                        random_state=42,
                    ),
                ),
            ]
        ),

        "Random Forest": RandomForestClassifier(
            n_estimators=300,
            class_weight="balanced",
            random_state=42,
            n_jobs=-1,
        ),

        "Gradient Boosting": GradientBoostingClassifier(
            random_state=42,
        ),

        "XGBoost": XGBClassifier(
            n_estimators=300,
            max_depth=4,
            learning_rate=0.05,
            subsample=0.8,
            colsample_bytree=0.8,
            objective="binary:logistic",
            eval_metric="logloss",
            random_state=42,
            n_jobs=-1,
        ),
    }

    return modelos



def avaliar_modelo(modelo, x_train, y_train, x_test, y_test):
    modelo.fit(x_train, y_train)

    y_pred = modelo.predict(x_test)

    try:
        y_proba = modelo.predict_proba(x_test)[:, 1]
        auc = roc_auc_score(y_test, y_proba)
    except Exception:
        auc = None

    acc = accuracy_score(y_test, y_pred)
    f1_macro = f1_score(y_test, y_pred, average="macro")
    f1_toxico = f1_score(y_test, y_pred, pos_label=1)

    return {
        "acuracia": round(acc, 4),
        "f1_macro": round(f1_macro, 4),
        "f1_toxico": round(f1_toxico, 4),
        "auc_roc": round(auc, 4) if auc is not None else None,
        "classification_report": classification_report(y_test, y_pred, digits=4),
    }


def executar_cross_dataset(df: pd.DataFrame) -> pd.DataFrame:
    feature_cols = obter_colunas_features(df)
    modelos = criar_modelos()
    datasets = sorted(df["dataset"].unique())

    resultados = []

    print("Features utilizadas:")
    print(feature_cols)

    for dataset_treino in datasets:
        for dataset_teste in datasets:
            if dataset_treino == dataset_teste:
                continue

            df_train = df[df["dataset"] == dataset_treino].copy()
            df_test = df[df["dataset"] == dataset_teste].copy()

            x_train = df_train[feature_cols]
            y_train = df_train["rotulo"]

            x_test = df_test[feature_cols]
            y_test = df_test["rotulo"]

            for nome_modelo, modelo in modelos.items():
                print("=" * 80)
                print(f"Modelo: {nome_modelo}")
                print(f"Treino: {dataset_treino} | Teste: {dataset_teste}")

                metricas = avaliar_modelo(
                    modelo=modelo,
                    x_train=x_train,
                    y_train=y_train,
                    x_test=x_test,
                    y_test=y_test,
                )

                print(metricas["classification_report"])

                resultados.append(
                    {
                        "modelo": nome_modelo,
                        "treino": dataset_treino,
                        "teste": dataset_teste,
                        "n_treino": len(df_train),
                        "n_teste": len(df_test),
                        "acuracia": metricas["acuracia"],
                        "f1_macro": metricas["f1_macro"],
                        "f1_toxico": metricas["f1_toxico"],
                        "auc_roc": metricas["auc_roc"],
                    }
                )

    return pd.DataFrame(resultados)


def main():
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    df = carregar_features()

    print("Arquivo carregado:")
    print(df.head())

    print("\nQuantidade por dataset:")
    print(df["dataset"].value_counts())

    print("\nDistribuição dos rótulos:")
    print(pd.crosstab(df["dataset"], df["rotulo"]))

    resultados = executar_cross_dataset(df)

    print("\nResultados consolidados:")
    print(resultados)

    output_path = RESULTS_DIR / "modelos_tabulares_cross_dataset.csv"
    resultados.to_csv(output_path, index=False, encoding="utf-8")

    print(f"\nResultados salvos em: {output_path}")


if __name__ == "__main__":
    main()