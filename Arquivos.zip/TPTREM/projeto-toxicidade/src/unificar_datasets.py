from pathlib import Path

import pandas as pd


DATA_PROCESSED = Path("data/processed")


def carregar_csv_obrigatorio(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(
            f"Arquivo não encontrado: {path}. "
            "Execute antes o respectivo script de carregamento."
        )

    return pd.read_csv(path)


def main():
    arquivos = [
        DATA_PROCESSED / "toldbr_processado.csv",
        DATA_PROCESSED / "hatebrxplain_processado.csv",
        DATA_PROCESSED / "olidbr_processado.csv",
    ]

    dfs = []

    for arquivo in arquivos:
        df = carregar_csv_obrigatorio(arquivo)
        dfs.append(df)
        print(f"Carregado: {arquivo} | {df.shape}")

    df_all = pd.concat(dfs, ignore_index=True)

    df_all = df_all.dropna(subset=["texto", "rotulo", "dataset"])
    df_all["texto"] = df_all["texto"].astype(str).str.strip()
    df_all = df_all[df_all["texto"].str.len() > 0]
    df_all = df_all.drop_duplicates(subset=["texto", "dataset"])
    df_all["rotulo"] = df_all["rotulo"].astype(int)

    print("\nDataset unificado:")
    print(df_all.head())

    print("\nQuantidade total:")
    print(len(df_all))

    print("\nQuantidade por dataset:")
    print(df_all["dataset"].value_counts())

    print("\nDistribuição dos rótulos por dataset:")
    print(pd.crosstab(df_all["dataset"], df_all["rotulo"]))

    print("\nProporção dos rótulos por dataset:")
    print(pd.crosstab(df_all["dataset"], df_all["rotulo"], normalize="index"))

    output_path = DATA_PROCESSED / "datasets_unificados.csv"
    df_all.to_csv(output_path, index=False, encoding="utf-8")

    print(f"\nArquivo salvo em: {output_path}")


if __name__ == "__main__":
    main()