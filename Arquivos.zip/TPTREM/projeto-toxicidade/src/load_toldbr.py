from pathlib import Path

import pandas as pd


DATA_PROCESSED = Path("data/processed")


def carregar_toldbr() -> pd.DataFrame:
    """
    Carrega o ToLD-BR diretamente do GitHub e padroniza para:
    texto | rotulo | dataset

    rotulo:
    1 = tóxico
    0 = não tóxico
    """

    url = "https://raw.githubusercontent.com/JAugusto97/ToLD-Br/main/ToLD-BR.csv"

    df = pd.read_csv(url)

    print("Colunas originais:")
    print(df.columns)
    print("\nFormato original:", df.shape)
    print("\nPrimeiras linhas:")
    print(df.head())

    # Colunas de toxicidade do ToLD-BR.
    toxic_cols = [
        "homophobia",
        "obscene",
        "insult",
        "racism",
        "misogyny",
        "xenophobia",
    ]

    # Garante que as colunas esperadas existem.
    colunas_faltando = [col for col in toxic_cols if col not in df.columns]
    if colunas_faltando:
        raise ValueError(f"Colunas não encontradas no dataset: {colunas_faltando}")

    if "text" not in df.columns:
        raise ValueError(f"Coluna 'text' não encontrada. Colunas disponíveis: {list(df.columns)}")

    df["texto"] = df["text"].astype(str).str.strip()

    # Cada categoria vai de 0 a 3.
    # Consideramos tóxico quando pelo menos 2 anotadores marcaram alguma categoria.
    df["rotulo"] = (df[toxic_cols].max(axis=1) >= 2).astype(int)

    df_final = df[["texto", "rotulo"]].copy()
    df_final["dataset"] = "ToLD-BR"

    df_final = df_final.dropna()
    df_final = df_final[df_final["texto"].str.len() > 0]
    df_final = df_final.drop_duplicates(subset=["texto"])
    df_final = df_final.reset_index(drop=True)

    return df_final


if __name__ == "__main__":
    DATA_PROCESSED.mkdir(parents=True, exist_ok=True)

    df_toldbr = carregar_toldbr()

    print("\nDataset processado:")
    print(df_toldbr.head())

    print("\nQuantidade de exemplos:")
    print(len(df_toldbr))

    print("\nDistribuição dos rótulos:")
    print(df_toldbr["rotulo"].value_counts())

    print("\nProporção dos rótulos:")
    print(df_toldbr["rotulo"].value_counts(normalize=True))

    output_path = DATA_PROCESSED / "toldbr_processado.csv"
    df_toldbr.to_csv(output_path, index=False, encoding="utf-8")

    print(f"\nArquivo salvo em: {output_path}")