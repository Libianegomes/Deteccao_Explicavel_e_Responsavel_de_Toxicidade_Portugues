from pathlib import Path
import re
import unicodedata

import pandas as pd


DATA_PROCESSED = Path("data/processed")


PALAVRAS_OFENSIVAS_EXEMPLO = {
    "idiota",
    "burro",
    "burra",
    "lixo",
    "merda",
    "porra",
    "otario",
    "otaria",
    "imbecil",
    "ridiculo",
    "ridicula",
}


def remover_acentos(texto: str) -> str:
    texto = unicodedata.normalize("NFKD", texto)
    return "".join(char for char in texto if not unicodedata.combining(char))


def tokenizar(texto: str) -> list[str]:
    texto = remover_acentos(texto.lower())
    return re.findall(r"\b\w+\b", texto)


def extrair_features_textuais(texto: str) -> dict:
    texto = str(texto)
    tokens = tokenizar(texto)

    n_chars = len(texto)
    n_words = len(tokens)

    palavras_caixa_alta = re.findall(r"\b[A-ZÁÉÍÓÚÂÊÔÃÕÇ]{2,}\b", texto)

    n_palavras_ofensivas = sum(
        1 for token in tokens if token in PALAVRAS_OFENSIVAS_EXEMPLO
    )

    return {
        "n_chars": n_chars,
        "n_words": n_words,
        "avg_word_len": n_chars / n_words if n_words > 0 else 0,
        "n_exclamation": texto.count("!"),
        "n_question": texto.count("?"),
        "n_upper_words": len(palavras_caixa_alta),
        "upper_word_ratio": len(palavras_caixa_alta) / n_words if n_words > 0 else 0,
        "n_urls": len(re.findall(r"http\S+|www\.\S+", texto.lower())),
        "n_mentions": texto.count("@"),
        "n_hashtags": texto.count("#"),
        "n_palavras_ofensivas_exemplo": n_palavras_ofensivas,
        "has_palavra_ofensiva_exemplo": int(n_palavras_ofensivas > 0),
    }


def main():
    input_path = DATA_PROCESSED / "datasets_unificados.csv"

    if not input_path.exists():
        raise FileNotFoundError(
            f"Arquivo não encontrado: {input_path}. "
            "Execute antes o script src/unificar_datasets.py."
        )

    df = pd.read_csv(input_path)

    print("Arquivo carregado:")
    print(df.head())

    features = df["texto"].apply(extrair_features_textuais)
    df_features = pd.DataFrame(features.tolist())

    df_saida = pd.concat(
        [
            df[["texto", "rotulo", "dataset"]].reset_index(drop=True),
            df_features.reset_index(drop=True),
        ],
        axis=1,
    )

    print("\nDataset com features:")
    print(df_saida.head())

    print("\nColunas geradas:")
    print(df_saida.columns)

    output_path = DATA_PROCESSED / "features_tabulares.csv"
    df_saida.to_csv(output_path, index=False, encoding="utf-8")

    print(f"\nArquivo salvo em: {output_path}")


if __name__ == "__main__":
    main()