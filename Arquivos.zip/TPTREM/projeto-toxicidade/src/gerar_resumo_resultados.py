from pathlib import Path

import pandas as pd
import matplotlib.pyplot as plt


RESULTS_DIR = Path("results")
FIGURES_DIR = Path("reports/figures")


def carregar_resultados() -> pd.DataFrame:
    arquivos = [
        RESULTS_DIR / "baseline_cross_dataset.csv",
        RESULTS_DIR / "modelos_tabulares_cross_dataset.csv",
    ]

    dfs = []

    for arquivo in arquivos:
        if arquivo.exists():
            df = pd.read_csv(arquivo)
            dfs.append(df)
            print(f"Arquivo carregado: {arquivo}")
        else:
            print(f"Aviso: arquivo não encontrado: {arquivo}")

    if not dfs:
        raise FileNotFoundError(
            "Nenhum arquivo de resultado foi encontrado. "
            "Execute antes os scripts de treino."
        )

    return pd.concat(dfs, ignore_index=True)


def gerar_resumos(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    df["cenario"] = df["treino"] + " -> " + df["teste"]

    df = df.sort_values(
        by=["cenario", "f1_macro"],
        ascending=[True, False],
    )

    todos_path = RESULTS_DIR / "todos_resultados.csv"
    df.to_csv(todos_path, index=False, encoding="utf-8")
    print(f"Resultados consolidados salvos em: {todos_path}")

    resumo_por_modelo = (
        df.groupby("modelo")
        .agg(
            media_f1_macro=("f1_macro", "mean"),
            desvio_f1_macro=("f1_macro", "std"),
            media_acuracia=("acuracia", "mean"),
            media_auc_roc=("auc_roc", "mean"),
        )
        .reset_index()
        .sort_values(by="media_f1_macro", ascending=False)
        .round(4)
    )

    resumo_path = RESULTS_DIR / "resumo_por_modelo.csv"
    resumo_por_modelo.to_csv(resumo_path, index=False, encoding="utf-8")
    print(f"Resumo por modelo salvo em: {resumo_path}")

    melhor_por_cenario = (
        df.sort_values(by=["cenario", "f1_macro"], ascending=[True, False])
        .groupby("cenario")
        .head(1)
        .reset_index(drop=True)
    )

    melhor_path = RESULTS_DIR / "melhor_modelo_por_cenario.csv"
    melhor_por_cenario.to_csv(melhor_path, index=False, encoding="utf-8")
    print(f"Melhor modelo por cenário salvo em: {melhor_path}")

    print("\nResumo por modelo:")
    print(resumo_por_modelo)

    print("\nMelhor modelo por cenário:")
    print(
        melhor_por_cenario[
            ["cenario", "modelo", "f1_macro", "acuracia", "auc_roc"]
        ]
    )

    return df


def gerar_grafico(df: pd.DataFrame) -> None:
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)

    tabela = df.pivot_table(
        index="modelo",
        columns="cenario",
        values="f1_macro",
        aggfunc="mean",
    )

    ax = tabela.plot(kind="bar", figsize=(12, 6))

    ax.set_title("F1-macro por modelo em avaliação cross-dataset")
    ax.set_xlabel("Modelo")
    ax.set_ylabel("F1-macro")
    ax.legend(title="Cenário", bbox_to_anchor=(1.05, 1), loc="upper left")

    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()

    output_path = FIGURES_DIR / "f1_macro_por_modelo.png"
    plt.savefig(output_path, dpi=300)
    plt.close()

    print(f"Gráfico salvo em: {output_path}")


def main():
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)

    df_resultados = carregar_resultados()

    print("\nResultados carregados:")
    print(df_resultados.head())

    df_resultados = gerar_resumos(df_resultados)
    gerar_grafico(df_resultados)


if __name__ == "__main__":
    main()